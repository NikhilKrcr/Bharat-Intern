function convertToFar() {
    const celsiusInput = document.getElementById("celsiusInput").value;
    const fahrenheitOutput = document.getElementById("fahrenheitOutput");

    if (!celsiusInput) {
        alert("Please enter a valid Celsius temperature.");
        return;
    }

    const celsius = parseFloat(celsiusInput);
    const fahrenheit = (celsius * 9/5) + 32;

    fahrenheitOutput.value = fahrenheit.toFixed(2) + " °F";
}
